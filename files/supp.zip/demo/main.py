# A simple program that runs only with pytorch
import torch

def check_cuda():
    print('PyTorch version: {}'.format(torch.__version__))
    print('CUDA available: {}'.format(torch.cuda.is_available()))
    print('CuDNN enabled: {}'.format(torch.backends.cudnn.enabled))

if __name__ == '__main__':
    check_cuda()
